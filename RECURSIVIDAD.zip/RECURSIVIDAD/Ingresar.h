
#include <iostream>

using namespace std;

class Ingresar{
public:
	virtual char* ingresarDatos(char* msg) = 0;
    Ingresar(){} 
};


